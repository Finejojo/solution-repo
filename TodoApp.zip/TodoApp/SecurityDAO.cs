﻿using System;

public class SecurityDAO
{
	public bool FindUser()
	{

	}
}
