﻿using System;

public class SecurtityService
{
	var daoService = new SecurityDAO();
	public bool Authenticate()
	{
		daoService.Fin
	}
}
