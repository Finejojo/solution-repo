﻿namespace TodoApi.Model
{
    public class signinModel
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
